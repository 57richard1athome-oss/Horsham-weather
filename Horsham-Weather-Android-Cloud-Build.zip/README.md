# Horsham Weather — Android project

This Android project wraps the Warm Neutral Horsham Weather HTML dashboard in a WebView. The HTML dashboard is bundled locally, so it does not need to be hosted as a website. Live forecasts still require an internet connection.

## Build APK in the cloud using GitHub Actions

1. Create a GitHub account if you do not already have one.
2. Create a new repository (for example, `horsham-weather`). Extract this ZIP and upload the project files and folders to the repository root on the `main` branch. Keep `.github/workflows/build-apk.yml` intact; it is the automation that builds the APK.
3. Open the repository's **Actions** tab and select **Build Horsham Weather APK**.
4. Tap **Run workflow**. Wait for the workflow to finish successfully.
5. Open the completed run and download the artifact named **Horsham-Weather-APK**. Extract it to get `app-debug.apk`.
6. On your Samsung phone, tap the APK to install it. If Android asks, allow installation from the browser or file manager you used.

## Important
- This repository is source code plus an automated build workflow, not a prebuilt APK.
- The APK is unsigned for Play Store distribution (Android debug-signed for personal installation).
- The cloud workflow is included, but it has not been run from this environment, so the APK is not yet built or verified.
- The app fetches live weather data over the internet. Rain alerts are shown while the app is open; this project does not add background push notifications.
